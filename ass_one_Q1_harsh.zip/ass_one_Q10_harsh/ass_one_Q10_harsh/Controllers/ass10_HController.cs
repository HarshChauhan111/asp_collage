﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ass_one_Q10_harsh.Controllers
{
    public class ass10_HController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
